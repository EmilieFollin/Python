from PlayersPackage import Player

class Bot(Player):

	def __init__(self):
		pass