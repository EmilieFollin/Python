from PlayersPackage.Player import Player
from PlayersPackage.Human import Human
from PlayersPackage.Bot import Bot