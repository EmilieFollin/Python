from PlayersPackage import Player

class Human(Player):

	def __init__(self):
		pass